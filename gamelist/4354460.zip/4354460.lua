-- 4354460's Lua and Manifest Created by Hubcap Manifest
-- 幸存者笔记
-- Created: September 25, 2026 at 09:24:05 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(4354460) -- 幸存者笔记
-- MAIN APP DEPOTS
addappid(4354462, 1, "ed97435798a123a15a1d10cce5b19923d4fbb3a254fdfa9220edfca31f458e2a") -- Depot 4354462
setManifestid(4354462, "4498803194402353602", 36607149771)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(4354461) -- Depot 4354461 (empty depot)